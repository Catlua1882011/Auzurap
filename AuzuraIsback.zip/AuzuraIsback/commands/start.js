const { sendToDiscord } = require('../Discord');

module.exports = (bot, userData, questData, generateCode, maskIP, BASE_URL) => {
    bot.start(async (ctx) => {
        try {
            const userId = ctx.from.id.toString();
            const username = ctx.from.username || 'unknown';
            const firstName = ctx.from.first_name || 'User';
            
            if (!userData[userId]) {
                userData[userId] = {
                    id: userId,
                    username: username,
                    firstName: firstName,
                    verified: false,
                    coins: 0,
                    userIP: 'pending'
                };
                
                await sendToDiscord('player', {
                    name: username,
                    uid: userId,
                    ip: 'pending',
                    coins: 0
                });
            }
            
            const user = userData[userId];
            
            if (user.verified) {
                await ctx.reply(`Hello @${username} - ${userId}!\nIP: ${maskIP(user.userIP)}\n\nAlready verified.\nUse /menu for commands.`);
                return;
            }
            
            const verifyCode = generateCode();
            user.verifyCode = verifyCode;
            
            questData[`verify_${verifyCode}`] = {
                type: 'verify',
                userId: userId,
                username: username,
                userIP: 'pending',
                createdAt: Date.now()
            };
            
            await sendToDiscord('verify', {
                userId: userId,
                username: username,
                verified: false,
                ip: 'pending'
            });
            
            const verifyLink = `${BASE_URL}/verify?code=${verifyCode}&idacc=${userId}`;
            
            const keyboard = {
                inline_keyboard: [
                    [{ text: 'VERIFICATION', url: verifyLink }]
                ]
            };
            
            await ctx.reply(`Hello @${username} - ${userId}!\n\nSecurity Check\nClick button to:`, { reply_markup: keyboard });
            console.log(`[${userId}] /start - Username: @${username}`);
        } catch (error) {
            console.log('Error /start:', error.message);
        }
    });
};
