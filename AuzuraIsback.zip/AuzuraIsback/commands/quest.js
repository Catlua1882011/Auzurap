module.exports = (bot, userData, questData, isUserVerified, getUserDailyQuests, generateCode, createLink4MShortURL, usedQuestCodes, BASE_URL) => {
    bot.command('quest', async (ctx) => {
        try {
            const userId = ctx.from.id.toString();
            
            if (!isUserVerified(userId)) {
                await ctx.reply('Not verified!\nUse /start to verify.');
                return;
            }
            
            const user = userData[userId];
            const dailyQuests = getUserDailyQuests(userId);
            
            if (dailyQuests.completed >= dailyQuests.maxDaily) {
                await ctx.reply(`Daily Limit Reached!\n\nCompleted: ${dailyQuests.completed}/${dailyQuests.maxDaily}\n\nCome back tomorrow!`);
                console.log(`[${userId}] /quest - LIMIT - ${dailyQuests.completed}/${dailyQuests.maxDaily}`);
                return;
            }
            
            const questCode = generateCode();
            const callbackURL = `${BASE_URL}/quest-done?code=${questCode}&idacc=${userId}`;
            const shortURL = await createLink4MShortURL(callbackURL);
            
            questData[questCode] = {
                type: 'quest',
                userId: userId,
                username: user.username,
                link: shortURL || callbackURL,
                status: 'pending',
                createdAt: Date.now(),
                completedAt: null,
                coins: 2,
                views: 0,
                requiredViews: 1
            };
            
            dailyQuests.quests.push({
                code: questCode,
                createdAt: Date.now(),
                completed: false
            });
            
            setTimeout(() => {
                if (questData[questCode] && questData[questCode].status === 'pending') {
                    questData[questCode].status = 'expired';
                    delete questData[questCode];
                    usedQuestCodes.add(questCode);
                }
            }, 1800000);
            
            const keyboard = {
                inline_keyboard: [
                    [{ text: 'Link4M Quest', url: `${BASE_URL}/quest?code=${questCode}&idacc=${userId}` }]
                ]
            };
            
            const messageText = `Quest Today\n\nReward: 2 Coins / Link\nProgress: [${dailyQuests.completed}/${dailyQuests.maxDaily}]\n\nTime Limit: 30 minutes`;
            
            await ctx.reply(messageText, { reply_markup: keyboard });
            console.log(`[${userId}] /quest - NEW QUEST - Code: ${questCode} [${dailyQuests.completed + 1}/${dailyQuests.maxDaily}]`);
        } catch (error) {
            console.log('Error /quest:', error.message);
        }
    });
};
