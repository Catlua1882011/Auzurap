module.exports = (bot, userData, isUserVerified, maskIP) => {
    bot.command('check', async (ctx) => {
        try {
            const userId = ctx.from.id.toString();
            
            if (!isUserVerified(userId)) {
                await ctx.reply('Not verified!\nUse /start to verify.');
                return;
            }
            
            const user = userData[userId];
            const maskedIP = maskIP(user.userIP);
            const messageText = `Work | IP: ${maskedIP}`;
            
            await ctx.reply(messageText);
            console.log(`[${userId}] /check`);
        } catch (error) {
            console.log('Error /check:', error.message);
        }
    });
};
