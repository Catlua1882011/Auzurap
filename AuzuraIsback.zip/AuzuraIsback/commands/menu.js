module.exports = (bot, isUserVerified) => {
    bot.command('menu', async (ctx) => {
        try {
            const userId = ctx.from.id.toString();
            
            if (!isUserVerified(userId)) {
                await ctx.reply('Not verified!\nUse /start to verify.');
                return;
            }
            
            const menuText = `MENU\n\n/quest - Get daily quest\n/info - Account info\n/check - Check IP`;
            
            await ctx.reply(menuText);
            console.log(`[${userId}] /menu`);
        } catch (error) {
            console.log('Error /menu:', error.message);
        }
    });
};
