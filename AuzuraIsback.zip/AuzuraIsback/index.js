const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const net = require('net');
const { Telegraf } = require('telegraf');
const express = require('express');
const crypto = require('crypto');
const os = require('os');
const https = require('https');

const { sendToDiscord } = require('./Discord');

function autoInstallPackages() {
    const requiredPackages = ['telegraf', 'express', 'axios'];
    const nodeModulesPath = path.join(__dirname, 'node_modules');
    
    let needInstall = false;
    
    for (const pkg of requiredPackages) {
        const pkgPath = path.join(nodeModulesPath, pkg);
        if (!fs.existsSync(pkgPath)) {
            console.log(`📦 Package "${pkg}" chưa được cài đặt`);
            needInstall = true;
            break;
        }
    }
    
    if (needInstall) {
        console.log('🔄 Đang tự động cài đặt packages...');
        try {
            execSync('npm install telegraf express axios', { 
                stdio: 'inherit',
                cwd: __dirname 
            });
            console.log('✅ Cài đặt thành công!');
        } catch (error) {
            console.error('❌ Lỗi khi cài đặt packages:', error.message);
            process.exit(1);
        }
    } else {
        console.log('✅ Tất cả packages đã được cài đặt');
    }
}

function testHostConnection() {
    const HOST = 'fi2.bot-hosting.net';
    const PORT = 20711;
    
    console.log(`\n🔌 Đang thử kết nối tới ${HOST}:${PORT}...`);
    
    const client = new net.Socket();
    client.setTimeout(5000);
    
    client.on('connect', () => {
        console.log(`✅ KẾT NỐI THÀNH CÔNG tới ${HOST}:${PORT}`);
        client.write('PING\r\n');
    });
    
    client.on('data', (data) => {
        console.log('← Server trả về:', data.toString().trim());
    });
    
    client.on('close', () => {
        console.log('→ Kết nối đã đóng');
    });
    
    client.on('timeout', () => {
        console.log('⏱️ Timeout - server không phản hồi trong 5s');
        client.destroy();
    });
    
    client.on('error', (err) => {
        if (err.code === 'ECONNREFUSED') {
            console.log('❌ Không thể kết nối - server từ chối hoặc không mở cổng');
        } else if (err.code === 'ENOTFOUND') {
            console.log('❌ Sai tên miền / DNS không resolve được');
        } else {
            console.log('❌ Lỗi:', err.message);
        }
    });
    
    client.connect(PORT, HOST);
}

autoInstallPackages();
testHostConnection();

const BOT_TOKEN = '8423864233:AAHcCBdw-OWbXIhoTEtrxAX6nQhkG_vzh1o';
const BOT_USERNAME = 'your_bot_username';
const LINK4M_API = '6975f3e53944366592464568';
const BOT_HOSTING_HOST = 'fi2.bot-hosting.net';
const USE_BOT_HOSTING = true;
let PORT;
let BASE_URL;

const bot = new Telegraf(BOT_TOKEN);
const app = express();

app.use(express.json());
app.set('trust proxy', true);
app.use('/css', express.static(path.join(__dirname, 'Web/css')));

let questData = {};
let userData = {};
let userDailyQuests = {};
let usedQuestCodes = new Set();

function getLocalIP() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                return iface.address;
            }
        }
    }
    return '1.1.1.1';
}

function getClientIP(req) {
    return req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
           req.headers['x-real-ip'] ||
           req.headers['cf-connecting-ip'] ||
           req.connection.remoteAddress ||
           req.socket.remoteAddress ||
           req.ip ||
           'unknown';
}

function maskIP(ip) {
    if (ip === 'unknown' || ip === 'pending') return '****.***.***';
    const parts = ip.split('.');
    if (parts.length !== 4) return '****.***.***';
    return `${parts[0]}.${parts[1]}.***`;
}

function generateCode() {
    return crypto.randomBytes(12).toString('hex');
}

function getVietnamTime() {
    const now = new Date();
    const utcTime = now.getTime() + now.getTimezoneOffset() * 60000;
    const vietnamTime = new Date(utcTime + (7 * 60 * 60000));
    return vietnamTime;
}

function getTodayDateVietnam() {
    const vietnamTime = getVietnamTime();
    return vietnamTime.toISOString().split('T')[0];
}

async function createLink4MShortURL(longURL) {
    return new Promise((resolve) => {
        const headers = {
            'accept': 'application/json',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'user-agent': 'Mozilla/5.0'
        };
        
        const url = new URL(`https://link4m.co/api-shorten/v2?api=${LINK4M_API}&url=${encodeURIComponent(longURL)}`);
        
        const options = {
            hostname: url.hostname,
            path: url.pathname + url.search,
            method: 'GET',
            headers: headers
        };
        
        https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const json = JSON.parse(data);
                    const shortURL = json.shortenedUrl || json.short_url || json.shortUrl || json.url || json.link;
                    resolve(shortURL || null);
                } catch (e) {
                    if (data.startsWith('http')) {
                        resolve(data.trim());
                    } else {
                        resolve(null);
                    }
                }
            });
        }).on('error', () => resolve(null)).end();
    });
}

function isUserVerified(userId) {
    return userData[userId] && userData[userId].verified === true;
}

function getUserDailyQuests(userId) {
    const today = getTodayDateVietnam();
    if (!userDailyQuests[userId]) {
        userDailyQuests[userId] = {};
    }
    if (!userDailyQuests[userId][today]) {
        userDailyQuests[userId][today] = {
            completed: 0,
            maxDaily: 2,
            quests: []
        };
    }
    return userDailyQuests[userId][today];
}

function renderTemplate(templatePath, data) {
    let html = fs.readFileSync(path.join(__dirname, 'Web/html', templatePath), 'utf8');
    for (const [key, value] of Object.entries(data)) {
        const regex = new RegExp(`{{${key}}}`, 'g');
        html = html.replace(regex, value);
    }
    return html;
}

const LOCAL_IP = getLocalIP();

app.get('/', (req, res) => {
    const totalUsers = Object.keys(userData).length;
    const verifiedUsers = Object.values(userData).filter(u => u.verified).length;
    const activeQuests = Object.values(questData).filter(q => q.type === 'quest' && q.status === 'pending').length;
    
    const html = renderTemplate('home.html', {
        totalUsers,
        verifiedUsers,
        activeQuests
    });
    res.send(html);
});

app.get('/verify', async (req, res) => {
    try {
        const { code, idacc } = req.query;
        const verifyKey = `verify_${code}`;
        const clientIP = getClientIP(req);
        
        if (!code || !questData[verifyKey]) {
            return res.send(renderTemplate('error.html', {
                title: 'Invalid Link',
                message: 'Verification link is invalid or expired',
                helpText: 'Use /start in Telegram bot'
            }));
        }
        
        const verify = questData[verifyKey];
        verify.userIP = clientIP;
        
        if (userData[idacc]) {
            userData[idacc].userIP = clientIP;
        }
        
        if (usedQuestCodes.has(code)) {
            delete questData[verifyKey];
            return res.send(renderTemplate('error.html', {
                title: 'Link Already Used',
                message: 'This verification link has been used'
            }));
        }
        
        console.log(`[${idacc}] Verify page accessed - IP: ${clientIP}`);
        
        const html = renderTemplate('verify.html', {
            username: verify.username,
            userId: verify.userId,
            maskedIP: maskIP(clientIP),
            code: code,
            botUsername: BOT_USERNAME
        });
        res.send(html);
    } catch (error) {
        console.log('Error verify page:', error.message);
        res.status(500).send('Error');
    }
});

app.post('/api/verify', async (req, res) => {
    try {
        const { code, userId } = req.body;
        const verifyKey = `verify_${code}`;
        const clientIP = getClientIP(req);
        
        if (!code || !questData[verifyKey]) {
            return res.json({ success: false, message: 'Invalid code' });
        }
        
        if (usedQuestCodes.has(code)) {
            delete questData[verifyKey];
            return res.json({ success: false, message: 'Code already used' });
        }
        
        const verify = questData[verifyKey];
        const user = userData[userId];
        
        if (!user) {
            return res.json({ success: false, message: 'User not found' });
        }
        
        user.verified = true;
        user.userIP = clientIP;
        verify.userIP = clientIP;
        
        usedQuestCodes.add(code);
        delete questData[verifyKey];
        
        await sendToDiscord('verify', {
            userId: verify.userId,
            username: verify.username,
            verified: true,
            ip: clientIP
        });
        
        await sendToDiscord('player', {
            name: verify.username,
            uid: verify.userId,
            ip: clientIP,
            coins: user.coins
        });
        
        const maskedIP = maskIP(clientIP);
        
        try {
            await bot.telegram.sendMessage(userId, `Verify Done\nIP: ${maskedIP}\n\nUse /menu to see commands`);
        } catch (error) {
            console.log('Error sending message:', error.message);
        }
        
        console.log(`[${userId}] Verified - IP: ${clientIP}`);
        
        res.json({ success: true, message: 'Verified' });
    } catch (error) {
        console.log('Error verify API:', error.message);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

app.get('/quest', async (req, res) => {
    try {
        const { code, idacc } = req.query;
        const clientIP = getClientIP(req);
        
        if (!code || !questData[code]) {
            return res.send(renderTemplate('error.html', {
                title: 'Quest Not Found',
                message: 'Invalid or expired quest'
            }));
        }
        
        const quest = questData[code];
        
        if (quest.status === 'expired') {
            return res.send(renderTemplate('error.html', {
                title: 'Quest Expired',
                message: 'This quest has expired'
            }));
        }
        
        quest.views = (quest.views || 0) + 1;
        
        console.log(`[${idacc}] Quest opened - IP: ${clientIP} - Views: ${quest.views}`);
        
        const html = renderTemplate('quest.html', {
            coins: quest.coins,
            views: quest.views,
            requiredViews: quest.requiredViews,
            link: quest.link
        });
        res.send(html);
    } catch (error) {
        console.log('Error quest page:', error.message);
        res.status(500).send('Error');
    }
});

app.get('/quest-done', async (req, res) => {
    try {
        const { code, idacc } = req.query;
        const clientIP = getClientIP(req);
        
        if (!code || !questData[code]) {
            return res.send(renderTemplate('error.html', {
                title: 'Error',
                message: 'Invalid quest or expired'
            }));
        }
        
        const quest = questData[code];
        const timePassed = (Date.now() - quest.createdAt) / 1000;
        
        if (timePassed < 120) {
            return res.send(renderTemplate('error.html', {
                title: 'Too Fast',
                message: `Please wait at least 2 minutes\nTime passed: ${Math.floor(timePassed)}s / 120s`
            }));
        }
        
        if (quest.status === 'expired') {
            delete questData[code];
            return res.send(renderTemplate('error.html', {
                title: 'Quest Expired',
                message: 'This quest has expired'
            }));
        }
        
        if (quest.views < quest.requiredViews) {
            return res.send(renderTemplate('error.html', {
                title: 'Incomplete Quest',
                message: `Please open the Link4M page properly\nViews: ${quest.views}/${quest.requiredViews}`
            }));
        }
        
        const user = userData[idacc];
        if (!user) {
            return res.send(renderTemplate('error.html', {
                title: 'User Not Found',
                message: 'Invalid user ID'
            }));
        }
        
        quest.status = 'completed';
        quest.completedAt = Date.now();
        user.coins += quest.coins;
        
        const dailyQuests = getUserDailyQuests(idacc);
        dailyQuests.completed += 1;
        
        const questIndex = dailyQuests.quests.findIndex(q => q.code === code);
        if (questIndex !== -1) {
            dailyQuests.quests[questIndex].completed = true;
        }
        
        delete questData[code];
        
        await sendToDiscord('player', {
            name: user.username,
            uid: user.id,
            ip: user.userIP,
            coins: user.coins
        });
        
        try {
            await bot.telegram.sendMessage(idacc, `Quest Completed!\n\nReward: +${quest.coins} Coins\n\nTotal Coins: ${user.coins}\nDaily Progress: ${dailyQuests.completed}/${dailyQuests.maxDaily}`);
        } catch (error) {
            console.log('Error sending message:', error.message);
        }
        
        console.log(`[${idacc}] Quest Done - IP: ${clientIP} - Coin +${quest.coins} (Total: ${user.coins})`);
        
        const html = renderTemplate('quest-done.html', {
            coins: quest.coins,
            totalCoins: user.coins,
            completed: dailyQuests.completed,
            maxDaily: dailyQuests.maxDaily,
            botUsername: BOT_USERNAME
        });
        res.send(html);
    } catch (error) {
        console.log('Error quest done:', error.message);
        res.status(500).send('Error');
    }
});

setInterval(async () => {
    const client = new net.Socket();
    client.setTimeout(3000);
    
    client.connect(20711, 'fi2.bot-hosting.net', () => {
        client.write('KEEPALIVE\r\n');
        client.end();
    });
    
    client.on('error', () => {});
}, 60000);

setInterval(async () => {
    const serverStatus = {
        status: 'Online',
        ping: Math.floor(Math.random() * 50) + 10,
        serverIp: USE_BOT_HOSTING ? BOT_HOSTING_HOST : LOCAL_IP,
        port: PORT
    };
    await sendToDiscord('server', serverStatus);
}, 5 * 60 * 1000);

(async () => {
    PORT = 20711;
    BASE_URL = USE_BOT_HOSTING ? `http://${BOT_HOSTING_HOST}:${PORT}` : `http://${LOCAL_IP}:${PORT}`;
    
    require('./commands/start')(bot, userData, questData, generateCode, maskIP, BASE_URL);
    require('./commands/menu')(bot, isUserVerified);
    require('./commands/quest')(bot, userData, questData, isUserVerified, getUserDailyQuests, generateCode, createLink4MShortURL, usedQuestCodes, BASE_URL);
    require('./commands/info')(bot, userData, isUserVerified, maskIP);
    require('./commands/check')(bot, userData, isUserVerified, maskIP);
    
    bot.launch().catch(err => console.log('Error:', err.message));
    
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`\n✅ Hệ thống đã khởi động hoàn tất!`);
        console.log(`🚀 Server đang chạy tại: ${BASE_URL}`);
        console.log(`📡 Host: ${USE_BOT_HOSTING ? BOT_HOSTING_HOST : LOCAL_IP}:${PORT}`);
        console.log(`🤖 Bot: @${BOT_USERNAME}`);
        console.log(`⏰ ${new Date().toLocaleString('vi-VN')}\n`);
    });
})();

module.exports = app;
