const axios = require('axios');

const DISCORD_WEBHOOKS = {
    player: 'https://discord.com/api/webhooks/1466835311572160583/EIUU3SQxVVITssvYTHewhEzz_9lnP8-cHlrS994wTbqbKiPZJXbmGH4Tk3k9mkw54dT9',
    verify: 'https://discord.com/api/webhooks/1466835311572160583/EIUU3SQxVVITssvYTHewhEzz_9lnP8-cHlrS994wTbqbKiPZJXbmGH4Tk3k9mkw54dT9',
    server: 'https://discord.com/api/webhooks/1466835438638731285/ukwmH0Fs1N4fGLGSvELqaOHFjeBg30R7BV8xnoxAROdb6tlMbrExJ99OhLIxpXvr0Rj3'
};

function maskIP(ip) {
    if (ip === 'unknown' || ip === 'pending') return '****.***.***';
    const parts = ip.split('.');
    if (parts.length !== 4) return '****.***.***';
    return `${parts[0]}.${parts[1]}.***`;
}

async function sendToDiscord(webhookType, data) {
    try {
        const webhookUrl = DISCORD_WEBHOOKS[webhookType];
        if (!webhookUrl) return false;

        let embed;
        
        if (webhookType === 'player') {
            embed = {
                title: 'Player Data',
                color: 0x5865F2,
                fields: [
                    { name: 'Username', value: `@${data.name}`, inline: true },
                    { name: 'User ID', value: data.uid, inline: true },
                    { name: 'IP Address', value: data.ip || 'Unknown', inline: true },
                    { name: 'Coins', value: data.coins?.toString() || '0', inline: true }
                ],
                timestamp: new Date(),
                footer: { text: `Player #${data.uid}` }
            };
        } else if (webhookType === 'verify') {
            embed = {
                title: 'Verification Status',
                color: data.verified ? 0x57F287 : 0xED4245,
                fields: [
                    { name: 'User', value: `@${data.username} (${data.userId})`, inline: false },
                    { name: 'Status', value: data.verified ? 'Verified' : 'Not Verified', inline: true },
                    { name: 'IP', value: data.ip === 'pending' ? 'Checking...' : maskIP(data.ip), inline: true }
                ],
                timestamp: new Date(),
                footer: { text: data.verified ? 'Successfully Verified' : 'Verification Pending' }
            };
        } else if (webhookType === 'server') {
            embed = {
                title: 'Server Status',
                color: data.status === 'Online' ? 0x57F287 : 0xED4245,
                fields: [
                    { name: 'Status', value: data.status === 'Online' ? 'Online' : 'Offline', inline: true },
                    { name: 'Ping', value: `${data.ping || 'N/A'} ms`, inline: true },
                    { name: 'Server IP', value: data.serverIp || 'N/A', inline: true },
                    { name: 'Port', value: data.port?.toString() || 'N/A', inline: true }
                ],
                timestamp: new Date(),
                footer: { text: 'Server Monitor' }
            };
        }

        await axios.post(webhookUrl, {
            username: 'Auzura Bot',
            avatar_url: 'https://i.imgur.com/AfFp7pu.png',
            embeds: [embed]
        });

        console.log(`[DISCORD] Sent ${webhookType} data successfully`);
        return true;
    } catch (error) {
        console.log(`[DISCORD] Error sending ${webhookType}: ${error.message}`);
        return false;
    }
}

module.exports = { sendToDiscord };
